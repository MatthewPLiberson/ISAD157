﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class index : Form
    {
        string query;
        public index()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                query = "SELECT * FROM ISAD157_MLiberson.users";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                query = "SELECT * FROM ISAD157_MLiberson.friendships";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                query = "SELECT * FROM ISAD157_MLiberson.messages";
            }
            if (comboBox1.SelectedIndex == 3)
            {
                query = "SELECT * FROM ISAD157_MLiberson.universities";
            }
            if (comboBox1.SelectedIndex == 4)
            {
                query = "SELECT * FROM ISAD157_MLiberson.workplace";
            }

            string connectionString = "SERVER=" + DBConnection.SERVER + ";" +
                    "DATABASE=" + DBConnection.DATABASE_NAME + ";" + "UID=" +
                    DBConnection.USER_NAME + ";" + "PASSWORD=" +
                    DBConnection.PASSWORD + ";" + "SslMode=" +
                    DBConnection.SslMode + ";" + "Allow Zero Datetime=true; ";

                using (MySqlConnection connection =
                    new MySqlConnection(connectionString))
                {

                    connection.Open();

                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
                    DataTable customerDataTable = new DataTable();
                    sqlDA.Fill(customerDataTable);

                    dataGridView1.DataSource = customerDataTable;

                }

            }
        }
    }
