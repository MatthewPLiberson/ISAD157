﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{   
    class DBConnection
    {
        internal const string USER_NAME = "ISAD157_MLiberson";
        internal const string SERVER = "proj-mysql.uopnet.plymouth.ac.uk";
        internal const string DATABASE_NAME = "ISAD157_MLiberson";
        internal const string PASSWORD = "ISAD157_22214399";
        internal const string SslMode = "none";
    }
}
